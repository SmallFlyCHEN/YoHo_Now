package com.example.dllo.yoho.Logon;

import android.view.View;

import com.example.dllo.yoho.R;
import com.example.dllo.yoho.base.BaseFragment;

/**
 * Created by dllo on 16/12/6.
 */
public class RegisterFragment extends BaseFragment {
    @Override
    protected int setLayout() {
        return R.layout.fragment_register;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
