package com.example.dllo.yoho.community;

import java.util.List;

/**
 * Created by dllo on 16/11/26.
 */
public class CommunityBean {


    /**
     * alg : SALT_MD5
     * code : 200
     * data : {"lastedTime":1479909802755,"list":[{"authorInfo":{"bgPic":"","headIcon":"http://head.static.yhbimg.com/yhb-head/2016/8/26/12/012c2770697a5fbb123c229dad8238f48c.975577.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"Yo君","signature":"YOHO!BUY饮水机管理员","uid":7950645},"blocks":[{"contentData":"前几周送情侣包包的活动，哪位同学抢到了？！\n\n现在又有NMD送啦！\n\n老规矩🤓\n\nstep1：微信搜索公众号\u201cYOHOBUY\u201d\nstep2：发送关键词\u201c我要NMD\u201d给公众号即可参与\n\n各位小伙伴奔走相告🏃🏼\u200d♀️🏃🏃🏼\u200d♀️🏃🏃🏼\u200d♀️🏃\n不要再跟我说没抢到NMD咯！","order":1,"templateKey":"text"},{"contentData":"http://img11.static.yhbimg.com/social/2016/11/24/15/01b50333b9ca1af3a3d1eca2e33b019a5b.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"}],"browse":0,"comment":14,"createTime":1479971367114,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106687,"indexTopTime":1511507929859,"isForumTop":0,"isHot":0,"isIndexTop":1,"postsTitle":"NMD免费送！Yo君又为大家争取福利啦！😍😍😍","praise":116,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480292569803},{"authorInfo":{"bgPic":"","headIcon":"http://head.static.yhbimg.com/yhb-head/2016/8/26/12/012c2770697a5fbb123c229dad8238f48c.975577.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"Yo君","signature":"YOHO!BUY饮水机管理员","uid":7950645},"blocks":[{"contentData":"之前玩ins的时候发现朋友圈之中只有我一个人在玩，便迎来了走在冷风中的冻感。。。。。。一个人的社交网络实在是太无聊了好嘛！！！！ ！ \r\n\r\n想成为网红？\r\n想结交潮人朋友？ \r\n想走进潮流圈？ \r\n觉得自己平时的穿搭审美很孤独？\r\n根本没有人懂？ \r\n想获取最新潮流资讯？ \r\n想分享时下最热潮流单品？ \r\n想买潮品又不知道什么地方可以买？ \r\n想参加大型潮流活动？ \r\n想fo紧余文乐？ \r\n想要","order":1,"templateKey":"text"},{"contentData":"http://img10.static.yhbimg.com/yhb-img01/2016/08/26/13/01bdf4920f5dec13c129a1ddaa6aaeef20.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"}],"browse":0,"comment":154,"createTime":1472188463478,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":27553,"indexTopTime":1503724483040,"isForumTop":0,"isHot":0,"isIndexTop":1,"postsTitle":"Welcome：一起玩YOHO!潮流社区，你就是最潮的那个人！","praise":256,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480288921572},{"authorInfo":{"bgPic":"http://img13.static.yhbimg.com/social/2016/11/24/11/0228db1b3555470f3d75f16772a4037530.jpg?imageView/{mode}/w/{width}/h/{height}","headIcon":"http://head.static.yhbimg.com/yhb-head/2016/10/17/11/041ba4a210a6fc8c6c23ca55c46641c51e.682634.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"JerryHuang","signature":"","uid":7450519},"blocks":[{"contentData":"http://img13.static.yhbimg.com/social/2016/11/25/09/02be2e675756ce7fbe7952983d3319cc8c.jpg?imageView/{mode}/w/{width}/h/{height}","order":1,"templateKey":"image"}],"browse":0,"comment":6,"createTime":1480037433240,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106760,"indexTopTime":1480037433240,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"满满的回忆","praise":41,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480221633682},{"authorInfo":{"bgPic":"http://img13.static.yhbimg.com/social/2016/11/24/11/0228db1b3555470f3d75f16772a4037530.jpg?imageView/{mode}/w/{width}/h/{height}","headIcon":"http://head.static.yhbimg.com/yhb-head/2016/10/17/11/041ba4a210a6fc8c6c23ca55c46641c51e.682634.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"JerryHuang","signature":"","uid":7450519},"blocks":[{"contentData":"http://img12.static.yhbimg.com/social/2016/11/25/09/020549d3baec78ce0118f5132cf8493bfa.jpg?imageView/{mode}/w/{width}/h/{height}","order":1,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/25/09/02ac428181b3630215a29215fc43b598cd.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/25/09/02ab4e4edd3f9bc5f2739548286670a364.jpg?imageView/{mode}/w/{width}/h/{height}","order":3,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/25/09/022789cd4ff0c8d03e373cb39bf624ba26.jpg?imageView/{mode}/w/{width}/h/{height}","order":4,"templateKey":"image"}],"browse":0,"comment":8,"createTime":1480037130270,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106758,"indexTopTime":1480037130270,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"卡戴珊家族，大家懂的","praise":45,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480140727957},{"authorInfo":{"bgPic":"","headIcon":"http://img02.yohoboys.com/contentimg/2016/11/15/23/02bdda8736e8e27554380a3fb329c23173.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"寿正斋","uid":16072687},"blocks":[{"contentData":"簡單晚餐","order":1,"templateKey":"text"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/24/20/01f5ba162154588aa1fa9b2b4aff983216.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/24/20/01bc29f3bd83c36d1f59780bc8676710cc.jpg?imageView/{mode}/w/{width}/h/{height}","order":3,"templateKey":"image"}],"browse":0,"comment":10,"createTime":1479990355273,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106737,"indexTopTime":1479990355273,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"","praise":15,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480165659430},{"authorInfo":{"bgPic":"","headIcon":"http://img02.res.yohoshow.com/headimg/2016/08/04/22/02b84a0d880d6653e5dd5aee9ef9be8ad0.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"Stephanie Tang","uid":8953167},"blocks":[{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/17/02f6f5a6e6a1e461d7d39ead4813b94dd1.jpg?imageView/{mode}/w/{width}/h/{height}","order":1,"templateKey":"image"},{"contentData":"http://img11.static.yhbimg.com/social/2016/11/24/17/011dc6eb501f337b2be0a0171ab0b7e12b.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/17/027e1c5c5c119c2e52beda964213a9a3a8.jpg?imageView/{mode}/w/{width}/h/{height}","order":3,"templateKey":"image"}],"browse":0,"comment":10,"createTime":1479979442919,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106711,"indexTopTime":1479979442919,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"💙💚❤️💛💜","praise":99,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480220433171},{"authorInfo":{"bgPic":"","headIcon":"http://img01.yohomars.com/mars/2016/11/18/ecd884946f072d57ad1e0a2445ffc84d.png?imageView/{mode}/w/{width}/h/{height}","nickName":"丸子欧尼酱","signature":"","uid":1195697},"blocks":[{"contentData":"Jasonwood推出的牛仔厨房概念会推出定制牛仔及微定制牛仔产品，推荐杭州的盆友们，新店已开，看上去就超级赞😁😁😁","order":1,"templateKey":"text"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/15/024142f1751f82de2603d28237263c4225.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"},{"contentData":"http://img11.static.yhbimg.com/social/2016/11/24/15/01bca2d1abda126bce43fa2372928614cd.jpg?imageView/{mode}/w/{width}/h/{height}","order":3,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/15/0274a461b1cb2563f29fa1a47dea7baa1d.jpg?imageView/{mode}/w/{width}/h/{height}","order":4,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/15/02b62570b5cd3ed24cb3eb65dcdcac2ada.jpg?imageView/{mode}/w/{width}/h/{height}","order":5,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/15/02a58e88e7796df94365ccc1e2d8fb7adf.jpg?imageView/{mode}/w/{width}/h/{height}","order":6,"templateKey":"image"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/24/15/013435fe35bb95baeae0c12510fe89d223.jpg?imageView/{mode}/w/{width}/h/{height}","order":7,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/24/15/02068670f4d831bfdc93b989774ebc8fa6.jpg?imageView/{mode}/w/{width}/h/{height}","order":8,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/24/15/02cd882501e29c88cd255b194fc667d077.jpg?imageView/{mode}/w/{width}/h/{height}","order":9,"templateKey":"image"},{"contentData":"http://img11.static.yhbimg.com/social/2016/11/24/15/015fc50b32ab66d61ebb574fc1724b072d.jpg?imageView/{mode}/w/{width}/h/{height}","order":10,"templateKey":"image"}],"browse":0,"comment":5,"createTime":1479972933714,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106690,"indexTopTime":1479972933714,"isForumTop":0,"isHot":1,"isIndexTop":0,"praise":38,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480178826095},{"authorInfo":{"bgPic":"http://img12.static.yhbimg.com/social/2016/11/06/22/021c69626347ae786ed36a57b8d5f6e172.jpg?imageView/{mode}/w/{width}/h/{height}","headIcon":"http://head.static.yhbimg.com/yhb-head/2016/10/19/15/046d188c513c3a61e56d43a8f4617dfecd.031810.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"请与我相恋的上一句","signature":"你失散多年的粗眉本宝宝","uid":6337673},"blocks":[{"contentData":"落叶收集者","order":1,"templateKey":"text"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/24/14/0126e72e559aa17c1cebe3f87253703368.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"}],"browse":0,"comment":13,"createTime":1479967643837,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106672,"indexTopTime":1479967643837,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"🍁","praise":44,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480149029626},{"authorInfo":{"bgPic":"","headIcon":"http://img02.yohoboys.com/contentimg/2016/10/17/10/029f599258d4e0bf88a218a405499603b8.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"Francsssss","signature":"啦啦阿拉","uid":8573181},"blocks":[{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/10/02f694e319aed92693518ab1e295e77177.jpg?imageView/{mode}/w/{width}/h/{height}","order":1,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/10/0232967ef50c242dcdfe198a903a054c30.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/24/10/01e7696824066d3a311e4f2c164d3c47aa.jpg?imageView/{mode}/w/{width}/h/{height}","order":3,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/10/029be5c8bec44f29c987dc69e6ca5dd692.jpg?imageView/{mode}/w/{width}/h/{height}","order":4,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/24/10/02f900a5e7b80f38942b6e2157072268c5.jpg?imageView/{mode}/w/{width}/h/{height}","order":5,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/10/029c4db0020a256d131b6de1c5b65ce83e.jpg?imageView/{mode}/w/{width}/h/{height}","order":6,"templateKey":"image"}],"browse":0,"comment":5,"createTime":1479954758472,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106659,"indexTopTime":1479954758472,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"60年代是最酷的年代👑","praise":23,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480140530830},{"authorInfo":{"bgPic":"","headIcon":"http://wx.qlogo.cn/mmopen/PiajxSqBRaEKqiaQKlW5z9Eg41r3XTX3YLPy4EYrxOvlYdM6ceuByz7GQR0sbF43BJgNnZg5C04Wzf5zDkHM1GtQ/0?imageView/{mode}/w/{width}/h/{height}","nickName":"LydiaMao","signature":"","uid":16150165},"blocks":[{"contentData":"\u201c1975年的ZARA\u201d\n\u201c所有的梦想始于卑微\u201d\n加油！","order":1,"templateKey":"text"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/23/22/01edb9bad862e45908b35aab82748e3c61.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"}],"browse":0,"comment":9,"createTime":1479909802755,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106638,"indexTopTime":1479909802755,"isForumTop":0,"isHot":1,"isIndexTop":0,"praise":72,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480094587309}],"pageSize":10,"total":471}
     * md5 : 87840abdfe58614cef7e9b9c69b50a59
     * message : 社区最热帖子列表
     */

    private String alg;
    private int code;
    private DataBean data;
    private String md5;
    private String message;

    public String getAlg() {
        return alg;
    }

    public void setAlg(String alg) {
        this.alg = alg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class DataBean {
        /**
         * lastedTime : 1479909802755
         * list : [{"authorInfo":{"bgPic":"","headIcon":"http://head.static.yhbimg.com/yhb-head/2016/8/26/12/012c2770697a5fbb123c229dad8238f48c.975577.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"Yo君","signature":"YOHO!BUY饮水机管理员","uid":7950645},"blocks":[{"contentData":"前几周送情侣包包的活动，哪位同学抢到了？！\n\n现在又有NMD送啦！\n\n老规矩🤓\n\nstep1：微信搜索公众号\u201cYOHOBUY\u201d\nstep2：发送关键词\u201c我要NMD\u201d给公众号即可参与\n\n各位小伙伴奔走相告🏃🏼\u200d♀️🏃🏃🏼\u200d♀️🏃🏃🏼\u200d♀️🏃\n不要再跟我说没抢到NMD咯！","order":1,"templateKey":"text"},{"contentData":"http://img11.static.yhbimg.com/social/2016/11/24/15/01b50333b9ca1af3a3d1eca2e33b019a5b.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"}],"browse":0,"comment":14,"createTime":1479971367114,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106687,"indexTopTime":1511507929859,"isForumTop":0,"isHot":0,"isIndexTop":1,"postsTitle":"NMD免费送！Yo君又为大家争取福利啦！😍😍😍","praise":116,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480292569803},{"authorInfo":{"bgPic":"","headIcon":"http://head.static.yhbimg.com/yhb-head/2016/8/26/12/012c2770697a5fbb123c229dad8238f48c.975577.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"Yo君","signature":"YOHO!BUY饮水机管理员","uid":7950645},"blocks":[{"contentData":"之前玩ins的时候发现朋友圈之中只有我一个人在玩，便迎来了走在冷风中的冻感。。。。。。一个人的社交网络实在是太无聊了好嘛！！！！ ！ \r\n\r\n想成为网红？\r\n想结交潮人朋友？ \r\n想走进潮流圈？ \r\n觉得自己平时的穿搭审美很孤独？\r\n根本没有人懂？ \r\n想获取最新潮流资讯？ \r\n想分享时下最热潮流单品？ \r\n想买潮品又不知道什么地方可以买？ \r\n想参加大型潮流活动？ \r\n想fo紧余文乐？ \r\n想要","order":1,"templateKey":"text"},{"contentData":"http://img10.static.yhbimg.com/yhb-img01/2016/08/26/13/01bdf4920f5dec13c129a1ddaa6aaeef20.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"}],"browse":0,"comment":154,"createTime":1472188463478,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":27553,"indexTopTime":1503724483040,"isForumTop":0,"isHot":0,"isIndexTop":1,"postsTitle":"Welcome：一起玩YOHO!潮流社区，你就是最潮的那个人！","praise":256,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480288921572},{"authorInfo":{"bgPic":"http://img13.static.yhbimg.com/social/2016/11/24/11/0228db1b3555470f3d75f16772a4037530.jpg?imageView/{mode}/w/{width}/h/{height}","headIcon":"http://head.static.yhbimg.com/yhb-head/2016/10/17/11/041ba4a210a6fc8c6c23ca55c46641c51e.682634.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"JerryHuang","signature":"","uid":7450519},"blocks":[{"contentData":"http://img13.static.yhbimg.com/social/2016/11/25/09/02be2e675756ce7fbe7952983d3319cc8c.jpg?imageView/{mode}/w/{width}/h/{height}","order":1,"templateKey":"image"}],"browse":0,"comment":6,"createTime":1480037433240,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106760,"indexTopTime":1480037433240,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"满满的回忆","praise":41,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480221633682},{"authorInfo":{"bgPic":"http://img13.static.yhbimg.com/social/2016/11/24/11/0228db1b3555470f3d75f16772a4037530.jpg?imageView/{mode}/w/{width}/h/{height}","headIcon":"http://head.static.yhbimg.com/yhb-head/2016/10/17/11/041ba4a210a6fc8c6c23ca55c46641c51e.682634.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"JerryHuang","signature":"","uid":7450519},"blocks":[{"contentData":"http://img12.static.yhbimg.com/social/2016/11/25/09/020549d3baec78ce0118f5132cf8493bfa.jpg?imageView/{mode}/w/{width}/h/{height}","order":1,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/25/09/02ac428181b3630215a29215fc43b598cd.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/25/09/02ab4e4edd3f9bc5f2739548286670a364.jpg?imageView/{mode}/w/{width}/h/{height}","order":3,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/25/09/022789cd4ff0c8d03e373cb39bf624ba26.jpg?imageView/{mode}/w/{width}/h/{height}","order":4,"templateKey":"image"}],"browse":0,"comment":8,"createTime":1480037130270,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106758,"indexTopTime":1480037130270,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"卡戴珊家族，大家懂的","praise":45,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480140727957},{"authorInfo":{"bgPic":"","headIcon":"http://img02.yohoboys.com/contentimg/2016/11/15/23/02bdda8736e8e27554380a3fb329c23173.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"寿正斋","uid":16072687},"blocks":[{"contentData":"簡單晚餐","order":1,"templateKey":"text"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/24/20/01f5ba162154588aa1fa9b2b4aff983216.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/24/20/01bc29f3bd83c36d1f59780bc8676710cc.jpg?imageView/{mode}/w/{width}/h/{height}","order":3,"templateKey":"image"}],"browse":0,"comment":10,"createTime":1479990355273,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106737,"indexTopTime":1479990355273,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"","praise":15,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480165659430},{"authorInfo":{"bgPic":"","headIcon":"http://img02.res.yohoshow.com/headimg/2016/08/04/22/02b84a0d880d6653e5dd5aee9ef9be8ad0.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"Stephanie Tang","uid":8953167},"blocks":[{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/17/02f6f5a6e6a1e461d7d39ead4813b94dd1.jpg?imageView/{mode}/w/{width}/h/{height}","order":1,"templateKey":"image"},{"contentData":"http://img11.static.yhbimg.com/social/2016/11/24/17/011dc6eb501f337b2be0a0171ab0b7e12b.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/17/027e1c5c5c119c2e52beda964213a9a3a8.jpg?imageView/{mode}/w/{width}/h/{height}","order":3,"templateKey":"image"}],"browse":0,"comment":10,"createTime":1479979442919,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106711,"indexTopTime":1479979442919,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"💙💚❤️💛💜","praise":99,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480220433171},{"authorInfo":{"bgPic":"","headIcon":"http://img01.yohomars.com/mars/2016/11/18/ecd884946f072d57ad1e0a2445ffc84d.png?imageView/{mode}/w/{width}/h/{height}","nickName":"丸子欧尼酱","signature":"","uid":1195697},"blocks":[{"contentData":"Jasonwood推出的牛仔厨房概念会推出定制牛仔及微定制牛仔产品，推荐杭州的盆友们，新店已开，看上去就超级赞😁😁😁","order":1,"templateKey":"text"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/15/024142f1751f82de2603d28237263c4225.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"},{"contentData":"http://img11.static.yhbimg.com/social/2016/11/24/15/01bca2d1abda126bce43fa2372928614cd.jpg?imageView/{mode}/w/{width}/h/{height}","order":3,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/15/0274a461b1cb2563f29fa1a47dea7baa1d.jpg?imageView/{mode}/w/{width}/h/{height}","order":4,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/15/02b62570b5cd3ed24cb3eb65dcdcac2ada.jpg?imageView/{mode}/w/{width}/h/{height}","order":5,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/15/02a58e88e7796df94365ccc1e2d8fb7adf.jpg?imageView/{mode}/w/{width}/h/{height}","order":6,"templateKey":"image"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/24/15/013435fe35bb95baeae0c12510fe89d223.jpg?imageView/{mode}/w/{width}/h/{height}","order":7,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/24/15/02068670f4d831bfdc93b989774ebc8fa6.jpg?imageView/{mode}/w/{width}/h/{height}","order":8,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/24/15/02cd882501e29c88cd255b194fc667d077.jpg?imageView/{mode}/w/{width}/h/{height}","order":9,"templateKey":"image"},{"contentData":"http://img11.static.yhbimg.com/social/2016/11/24/15/015fc50b32ab66d61ebb574fc1724b072d.jpg?imageView/{mode}/w/{width}/h/{height}","order":10,"templateKey":"image"}],"browse":0,"comment":5,"createTime":1479972933714,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106690,"indexTopTime":1479972933714,"isForumTop":0,"isHot":1,"isIndexTop":0,"praise":38,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480178826095},{"authorInfo":{"bgPic":"http://img12.static.yhbimg.com/social/2016/11/06/22/021c69626347ae786ed36a57b8d5f6e172.jpg?imageView/{mode}/w/{width}/h/{height}","headIcon":"http://head.static.yhbimg.com/yhb-head/2016/10/19/15/046d188c513c3a61e56d43a8f4617dfecd.031810.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"请与我相恋的上一句","signature":"你失散多年的粗眉本宝宝","uid":6337673},"blocks":[{"contentData":"落叶收集者","order":1,"templateKey":"text"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/24/14/0126e72e559aa17c1cebe3f87253703368.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"}],"browse":0,"comment":13,"createTime":1479967643837,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106672,"indexTopTime":1479967643837,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"🍁","praise":44,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480149029626},{"authorInfo":{"bgPic":"","headIcon":"http://img02.yohoboys.com/contentimg/2016/10/17/10/029f599258d4e0bf88a218a405499603b8.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"Francsssss","signature":"啦啦阿拉","uid":8573181},"blocks":[{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/10/02f694e319aed92693518ab1e295e77177.jpg?imageView/{mode}/w/{width}/h/{height}","order":1,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/10/0232967ef50c242dcdfe198a903a054c30.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/24/10/01e7696824066d3a311e4f2c164d3c47aa.jpg?imageView/{mode}/w/{width}/h/{height}","order":3,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/10/029be5c8bec44f29c987dc69e6ca5dd692.jpg?imageView/{mode}/w/{width}/h/{height}","order":4,"templateKey":"image"},{"contentData":"http://img12.static.yhbimg.com/social/2016/11/24/10/02f900a5e7b80f38942b6e2157072268c5.jpg?imageView/{mode}/w/{width}/h/{height}","order":5,"templateKey":"image"},{"contentData":"http://img13.static.yhbimg.com/social/2016/11/24/10/029c4db0020a256d131b6de1c5b65ce83e.jpg?imageView/{mode}/w/{width}/h/{height}","order":6,"templateKey":"image"}],"browse":0,"comment":5,"createTime":1479954758472,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106659,"indexTopTime":1479954758472,"isForumTop":0,"isHot":1,"isIndexTop":0,"postsTitle":"60年代是最酷的年代👑","praise":23,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480140530830},{"authorInfo":{"bgPic":"","headIcon":"http://wx.qlogo.cn/mmopen/PiajxSqBRaEKqiaQKlW5z9Eg41r3XTX3YLPy4EYrxOvlYdM6ceuByz7GQR0sbF43BJgNnZg5C04Wzf5zDkHM1GtQ/0?imageView/{mode}/w/{width}/h/{height}","nickName":"LydiaMao","signature":"","uid":16150165},"blocks":[{"contentData":"\u201c1975年的ZARA\u201d\n\u201c所有的梦想始于卑微\u201d\n加油！","order":1,"templateKey":"text"},{"contentData":"http://img10.static.yhbimg.com/social/2016/11/23/22/01edb9bad862e45908b35aab82748e3c61.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"}],"browse":0,"comment":9,"createTime":1479909802755,"forumCode":10001,"forumName":"潮流风向","hasPraise":"N","id":106638,"indexTopTime":1479909802755,"isForumTop":0,"isHot":1,"isIndexTop":0,"praise":72,"revieweState":0,"revieweTime":0,"status":0,"updateTime":1480094587309}]
         * pageSize : 10
         * total : 471
         */

        private long lastedTime;
        private int pageSize;
        private int total;
        private List<ListBean> list;

        public long getLastedTime() {
            return lastedTime;
        }

        public void setLastedTime(long lastedTime) {
            this.lastedTime = lastedTime;
        }

        public int getPageSize() {
            return pageSize;
        }

        public void setPageSize(int pageSize) {
            this.pageSize = pageSize;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            /**
             * authorInfo : {"bgPic":"","headIcon":"http://head.static.yhbimg.com/yhb-head/2016/8/26/12/012c2770697a5fbb123c229dad8238f48c.975577.jpg?imageView/{mode}/w/{width}/h/{height}","nickName":"Yo君","signature":"YOHO!BUY饮水机管理员","uid":7950645}
             * blocks : [{"contentData":"前几周送情侣包包的活动，哪位同学抢到了？！\n\n现在又有NMD送啦！\n\n老规矩🤓\n\nstep1：微信搜索公众号\u201cYOHOBUY\u201d\nstep2：发送关键词\u201c我要NMD\u201d给公众号即可参与\n\n各位小伙伴奔走相告🏃🏼\u200d♀️🏃🏃🏼\u200d♀️🏃🏃🏼\u200d♀️🏃\n不要再跟我说没抢到NMD咯！","order":1,"templateKey":"text"},{"contentData":"http://img11.static.yhbimg.com/social/2016/11/24/15/01b50333b9ca1af3a3d1eca2e33b019a5b.jpg?imageView/{mode}/w/{width}/h/{height}","order":2,"templateKey":"image"}]
             * browse : 0
             * comment : 14
             * createTime : 1479971367114
             * forumCode : 10001
             * forumName : 潮流风向
             * hasPraise : N
             * id : 106687
             * indexTopTime : 1511507929859
             * isForumTop : 0
             * isHot : 0
             * isIndexTop : 1
             * postsTitle : NMD免费送！Yo君又为大家争取福利啦！😍😍😍
             * praise : 116
             * revieweState : 0
             * revieweTime : 0
             * status : 0
             * updateTime : 1480292569803
             */

            private AuthorInfoBean authorInfo;
            private int browse;
            private int comment;
            private long createTime;
            private int forumCode;
            private String forumName;
            private String hasPraise;
            private int id;
            private long indexTopTime;
            private int isForumTop;
            private int isHot;
            private int isIndexTop;
            private String postsTitle;
            private int praise;
            private int revieweState;
            private int revieweTime;
            private int status;
            private long updateTime;
            private List<BlocksBean> blocks;

            public AuthorInfoBean getAuthorInfo() {
                return authorInfo;
            }

            public void setAuthorInfo(AuthorInfoBean authorInfo) {
                this.authorInfo = authorInfo;
            }

            public int getBrowse() {
                return browse;
            }

            public void setBrowse(int browse) {
                this.browse = browse;
            }

            public int getComment() {
                return comment;
            }

            public void setComment(int comment) {
                this.comment = comment;
            }

            public long getCreateTime() {
                return createTime;
            }

            public void setCreateTime(long createTime) {
                this.createTime = createTime;
            }

            public int getForumCode() {
                return forumCode;
            }

            public void setForumCode(int forumCode) {
                this.forumCode = forumCode;
            }

            public String getForumName() {
                return forumName;
            }

            public void setForumName(String forumName) {
                this.forumName = forumName;
            }

            public String getHasPraise() {
                return hasPraise;
            }

            public void setHasPraise(String hasPraise) {
                this.hasPraise = hasPraise;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public long getIndexTopTime() {
                return indexTopTime;
            }

            public void setIndexTopTime(long indexTopTime) {
                this.indexTopTime = indexTopTime;
            }

            public int getIsForumTop() {
                return isForumTop;
            }

            public void setIsForumTop(int isForumTop) {
                this.isForumTop = isForumTop;
            }

            public int getIsHot() {
                return isHot;
            }

            public void setIsHot(int isHot) {
                this.isHot = isHot;
            }

            public int getIsIndexTop() {
                return isIndexTop;
            }

            public void setIsIndexTop(int isIndexTop) {
                this.isIndexTop = isIndexTop;
            }

            public String getPostsTitle() {
                return postsTitle;
            }

            public void setPostsTitle(String postsTitle) {
                this.postsTitle = postsTitle;
            }

            public int getPraise() {
                return praise;
            }

            public void setPraise(int praise) {
                this.praise = praise;
            }

            public int getRevieweState() {
                return revieweState;
            }

            public void setRevieweState(int revieweState) {
                this.revieweState = revieweState;
            }

            public int getRevieweTime() {
                return revieweTime;
            }

            public void setRevieweTime(int revieweTime) {
                this.revieweTime = revieweTime;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public long getUpdateTime() {
                return updateTime;
            }

            public void setUpdateTime(long updateTime) {
                this.updateTime = updateTime;
            }

            public List<BlocksBean> getBlocks() {
                return blocks;
            }

            public void setBlocks(List<BlocksBean> blocks) {
                this.blocks = blocks;
            }

            public static class AuthorInfoBean {
                /**
                 * bgPic :
                 * headIcon : http://head.static.yhbimg.com/yhb-head/2016/8/26/12/012c2770697a5fbb123c229dad8238f48c.975577.jpg?imageView/{mode}/w/{width}/h/{height}
                 * nickName : Yo君
                 * signature : YOHO!BUY饮水机管理员
                 * uid : 7950645
                 */

                private String bgPic;
                private String headIcon;
                private String nickName;
                private String signature;
                private int uid;

                public String getBgPic() {
                    return bgPic;
                }

                public void setBgPic(String bgPic) {
                    this.bgPic = bgPic;
                }

                public String getHeadIcon() {
                    return headIcon;
                }

                public void setHeadIcon(String headIcon) {
                    this.headIcon = headIcon;
                }

                public String getNickName() {
                    return nickName;
                }

                public void setNickName(String nickName) {
                    this.nickName = nickName;
                }

                public String getSignature() {
                    return signature;
                }

                public void setSignature(String signature) {
                    this.signature = signature;
                }

                public int getUid() {
                    return uid;
                }

                public void setUid(int uid) {
                    this.uid = uid;
                }
            }

            public static class BlocksBean {
                /**
                 * contentData : 前几周送情侣包包的活动，哪位同学抢到了？！

                 现在又有NMD送啦！

                 老规矩🤓

                 step1：微信搜索公众号“YOHOBUY”
                 step2：发送关键词“我要NMD”给公众号即可参与

                 各位小伙伴奔走相告🏃🏼‍♀️🏃🏃🏼‍♀️🏃🏃🏼‍♀️🏃
                 不要再跟我说没抢到NMD咯！
                 * order : 1
                 * templateKey : text
                 */

                private String contentData;
                private int order;
                private String templateKey;

                public String getContentData() {
                    return contentData;
                }

                public void setContentData(String contentData) {
                    this.contentData = contentData;
                }

                public int getOrder() {
                    return order;
                }

                public void setOrder(int order) {
                    this.order = order;
                }

                public String getTemplateKey() {
                    return templateKey;
                }

                public void setTemplateKey(String templateKey) {
                    this.templateKey = templateKey;
                }
            }
        }
    }
}
