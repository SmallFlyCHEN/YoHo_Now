package com.example.dllo.yoho.video.videotwo;

import com.example.dllo.yoho.R;
import com.example.dllo.yoho.base.BaseActivity;

/**
 * Created by dllo on 16/12/10.
 */

public class VideoTwoActivity extends BaseActivity {
    @Override
    protected int setLayout() {
        return R.layout.activity_videotwo;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
