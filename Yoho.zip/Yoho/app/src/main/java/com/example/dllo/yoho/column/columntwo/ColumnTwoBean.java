package com.example.dllo.yoho.column.columntwo;

import java.util.List;

/**
 * Created by dllo on 16/12/9.
 */

public class ColumnTwoBean {

    /**
     * status : 0
     * code : 200000
     * data : {"content":[{"id":"22617","cid":"13355","create_time":"1480923508","publishURL":"http://www.yohoboys.com/channel/detail/index/id/13355","image":"http://img01.yohoboys.com/contentimg/2016/12/05/20/01b3ccbc8992811a8ef58c75e2384c2f49.png","width":738,"height":424,"contentType":0,"title":"SNKR Girl｜这群球鞋妹纸腿长身材好，让我忘记了现在是冬天！11.28-12.4","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"注意！注意！注意！[ 11.21 - 11.27 ]得奖的 SNKR Girls要揭晓了！[ 11.21 - 11.27 ]中获奖的SNKR Girls分别是：第一名：27号🎈 1024票第二名：7号Mumian_ZJ431票第三名：6号Olivia355票本期投稿的SNKR Girls如下：1号오","app":"1","updateMd5":"87210f2940dfdff0d674d43110c9a3ec","imgNum":0,"type":2,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"22517","cid":"13273","create_time":"1480665655","publishURL":"http://www.yohoboys.com/channel/detail/index/id/13273","image":"http://img01.yohoboys.com/contentimg/2016/12/02/15/01243b24c45e8344d1432c5fba626f00b4.png","width":738,"height":424,"contentType":0,"title":"那些年他在奇才穿过的Jordan球鞋","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"2001年9月25日，38岁的Michael Jordan再一次宣布复出，并与华盛顿奇才签订了为期2年的合同，这次复出的目的对于他本人来说是希望通过自己的能力帮助球队打入季后赛，但经过了两个赛季的尝试，最终未果。从Michael Jordan的整个职业生涯来看，在奇才队效力的两年更像是为了证明在这个","app":"1","updateMd5":"5f3e051798d94ad50f92cb6cbe7f557e","imgNum":0,"type":2,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"22231","cid":"13067","create_time":"1480329088","publishURL":"http://www.yohoboys.com/channel/detail/index/id/13067","image":"http://img01.yohoboys.com/contentimg/2016/11/28/18/016906b8d4e7b110ec89e873001f8bf9ce.jpg","width":738,"height":424,"contentType":0,"title":"SNKR Girl｜长腿Supreme、Bape Girl潮到爆，我并不想看鞋！11.21-11.27","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"注意！注意！注意！[ 11.14 - 11.20 ]得奖的 SNKR Girls要揭晓了！[ 11.14 - 11.20 ]中获奖的SNKR Girls分别是\n第一名：\n30号 \n_Kaito\n2756票\n第二、三名分别是：\n6号 \nUKl🌞\n1026票\n13号 \nBlack\n702票","app":"1","updateMd5":"19b0782a744e5b4fdfb34f447039b0ff","imgNum":0,"type":2,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"22075","cid":"12937","create_time":"1479903810","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12937","image":"http://img01.yohoboys.com/contentimg/2016/11/23/19/018908a6973dd654bb9fba74ec471e6838.jpg","width":620,"height":356,"contentType":0,"title":"Jordan Bastille新店开幕，限量Air Jordan黄金纯白套装有点贵","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"发展稳健的Jordan Brand 近日正式在巴黎开设首家零售店Jordan Bastille，为本次开业活动造势，品牌找来退役签约球员雷阿伦，并且一系列的全白白与黄金配色组成的 Air Jordan 套装出现在店铺橱柜之中。\n可以肯定是，本次整套Air Jordan 鞋款的出现旨在纪念本次店铺","app":"1","updateMd5":"bb22922f3342f90b5ccdf9af821ea420","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21999","cid":"12862","create_time":"1479818390","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12862","image":"http://img01.yohoboys.com/contentimg/2016/11/22/20/01a056e355ea5acec5134aac8c37a2031b.png","width":738,"height":424,"contentType":0,"title":"SNKR Girl｜带\u201c球\u201d撞人！犯规！11.14-11.20","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"注意！注意！注意！\n[ 11.7 - 11.13 ]得奖的 SNKR Girls要揭晓了！\n[ 11.7 - 11.13 ]中获奖的SNKR Girls分别是第一名：\n20号 \nAih 菲哥 \n4086票\n第二、三名分别是：\n25号 \n倾🕊 \n2631票\n5号 \nUKl🌞 \n","app":"1","updateMd5":"1c7f234b433131c6fde2cf24c4c7cf1d","imgNum":0,"type":2,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21796","cid":"12675","create_time":"1479204417","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12675","image":"http://img01.yohoboys.com/spidercms/2016/11/14/10/fb05a79f70fa948694c4ffd049e70707147909138084582924b4e3563","width":710,"height":394,"contentType":0,"title":"SNKR Girl｜一众潮爆Girl能否击败拿过第一的翘臀妹纸？！11.7-11.13","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"注意！注意！注意！[ 10.31 - 11.6 ]得奖的 SNKR Girls揭晓了！[ 10.31 - 11.6 ]中获奖的SNKR Girls分别是：\n第一名\n15号：Aih 菲哥我是你淇哥🌡 \n992票\n第二、三名分别是：\n28号：阿哈\n817票\n1号：🤗 Been There Don","app":"1","updateMd5":"8cb5782b29083ea0de84bc27707ad1b9","imgNum":0,"type":2,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21719","cid":"12609","create_time":"1478829956","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12609","image":"http://img02.yohoboys.com/contentimg/2016/11/11/03/027541a8c2592e841e8b1a5a2fbedc751f.jpg","width":650,"height":445,"contentType":4,"title":"Michael Lau巨作《Jordan 本色之墙》即将拍卖，天价在所难免","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"Michael Lau这个名字相信潮流爱好者都不会陌生，这位来自香港的艺术家，在Air Jordan 30周年之时展示出了自己的巨作《Jordan 本色志墙》。整个作品的灵感来自于粉丝对\u201c是什么让你成为 Jordan？\u201d这个问题，将粉丝的回答作为创作的元素。近日Jordan Brand决定对这幅巨作","app":"1","updateMd5":"0a0c096561bfe3b979fd8d0db7d68ea0","imgNum":11,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21554","cid":"12466","create_time":"1478230180","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12466","image":"http://img02.yohoboys.com/contentimg/2016/11/04/13/0264d40718774033c8a4a8d7013d1b430c.jpg","width":746,"height":747,"contentType":0,"title":"网友脑洞大开，仿造天价GUCCI拖鞋","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"日前GUCCI带来了品牌复古感极强的一个系列，双G与红绿的标志性设计再次引起大家的共鸣。但是毕竟是GUCCI，价格也摆在面前成为不少人的门槛。但是如果告诉你有一种低门槛方法让你拥有最近再次大热的红绿GUCCI拖鞋，你又会否感兴趣呢？有网友脑洞大开，亲自将自己的Air Jordan拖鞋进行改造，需要的","app":"1","updateMd5":"4d6c0962d3e609db91b8b9c1e1c366f8","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21333","cid":"12304","create_time":"1477283356","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12304","image":"http://img01.yohoboys.com/contentimg/2016/10/23/23/0114f1e7c7c0db26d11bfa79f878928b54.jpg","width":738,"height":424,"contentType":0,"title":"吸睛利器优选，爆裂纹加持全皮Air Jordan XXXI","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"作为Jordan Brand最新鞋款，Air Jordan XXXI 凝聚了品牌对于当今实战鞋款最强实力，值得注意的是推出之后相对频繁的配色更新也是眼前一亮。近日全新的\u201cBattle Grey\u201d爆裂纹配色正式推出。\n提起爆裂纹配色，更多的则是集中在Air Jordan 3上的火热，本次加持 Air ","app":"1","updateMd5":"8ef826593edae1933973513ded1ad852","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21283","cid":"12267","create_time":"1476845022","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12267","image":"http://img02.yohoboys.com/contentimg/2016/10/19/01/02262f21ece8ea58bc23f8a36f95e641d0.jpg","width":738,"height":424,"contentType":0,"title":"威少不满意新鞋？特别版本Air Jordan XXXI 亮相赛场","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"作为Jordan Brand的招牌代言人，雷霆队当家球星维斯布鲁克上脚球鞋无疑成为众多粉丝及鞋迷关注焦点，但近日一双实战鞋款让人倍感意外。\n提及意外元素，则是其在Air Jordan XXXI 的鞋面加持了Air Jordan XXX 的鞋底，这样的选择也是让人猜测绵绵。首先这双鞋款是否为延伸版的A","app":"1","updateMd5":"fe28e1fb266d8df1a5c6c667e728527f","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21217","cid":"12212","create_time":"1476247617","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12212","image":"http://img02.yohoboys.com/contentimg/2016/10/12/12/024d7ec5721420de516229ecda161b9d68.jpg","width":750,"height":527,"contentType":4,"title":"全新飞人足球靴现身，\u201cFire Red\u201d联名实物曝光","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"此前网络上一张内马尔与乔帮主的照片，引起网友的猜测会否带来合作，果不其然双方采用联名的方式发布了限定商品，其中足球靴与篮球鞋极受关注。近日曝光了第二弹的合作，而本次率先出现的是足球靴，鞋型选用毒蜂二代战靴，以招牌的\u201cFire Red\u201d配色贯彻，白红作为鞋款主要色调，泼墨元素作为设计细节，后跟出现标志","app":"1","updateMd5":"7bbfc223973b7478f6bbbbdc7fca8fec","imgNum":13,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21167","cid":"12174","create_time":"1475985751","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12174","image":"http://img01.yohoboys.com/contentimg/2016/10/09/09/0140540dc30c9544dd43ea0195e1b87d65.png","width":738,"height":424,"contentType":0,"title":"独特的北卡蓝魅力，Air Jordan XXXI新作配色现身","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"Air Jordan绵延至今已经成为众多粉丝必备之物，品牌也在发展中愈发活跃，今年发售的Air Jordan XXXI 在里约奥运会前夕推出后成功抢占多个标志配色，近日经典的\u201c北卡\u201d配色正式曝光。\n首先这款配色的曝光源自北卡大学篮球队官方 Instagram，这样一来可信度的提升对于产品发售将是直接","app":"1","updateMd5":"21c441dda9963e7cb83c30af5934738c","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21043","cid":"12077","create_time":"1474866214","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12077","image":"http://img01.yohoboys.com/contentimg/2016/09/26/12/01d0823479a5e37b8d791813d889dbf163.jpg","width":650,"height":445,"contentType":0,"title":"3款全新Air Jordan 11 low首次曝光","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"在Air Jordan的系列鞋款当中，Air Jordan 11 low长期保有较高的人气，成为不少鞋迷关注的焦点。近日网络上曝光了三款全新的Air Jordan 11 low全新配色，分别是纯白、黑银、蓝紫。他们的共同点都是以纯白中底结合抗氧化能力较好的淡蓝色水晶外底。据悉这三款全新的Air Jo","app":"1","updateMd5":"97124184fb396e3bad0a69b0215d9231","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20602","cid":"11698","create_time":"1473142906","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11698","image":"http://img02.yohoboys.com/contentimg/2016/09/06/13/02484764f322c1906c883bae8a7daec9c1.jpg","width":650,"height":445,"contentType":4,"title":"大黄靴即视感Air Jordan 4 Premium \u201cGinger\u201d","titleFont":"c","subTitleFont":"c","subtitle":"#球鞋星期二","summary":"此前网络上出现一双姜黄色Air Jordan 4，当时不少人对鞋子的外观褒贬不一。因为这双彻头彻尾都是姜黄色的Air Jordan 4颇有Timberland靴款的风范。目前随着更多的实物图片曝光，相信大家逐渐对这双\u201c踢不烂\u201dAir Jordan 4会有新的感觉。这双Air Jordan 4属于\u201cP","app":"1","updateMd5":"7e43ffb86a15b210898afc6ead299ac5","imgNum":11,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20582","cid":"11683","create_time":"1473048020","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11683","image":"http://img01.yohoboys.com/contentimg/2016/09/05/11/010fb766854fe8de9dd56bd4b49052eaab.jpg","width":650,"height":434,"contentType":0,"title":"Air Jordan 4\u201cPure Money\u201d约你明年6月见！","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"早前已经为各位预告过Pure Money纯白系列将会在明年复刻，根据最新消息复刻的Pure Money系列，除了Air Jordan 4这个经典鞋型，还会有Air Jordan 7和Air Jordan 13亦在复刻名单当中。目前关于实物谍照的图片仍未有曝光，相信会在近期出现相关实物谍照。而发售时间","app":"1","updateMd5":"f5c483b9e30327848236853c556cf839","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20425","cid":"11550","create_time":"1472019858","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11550","image":"http://img01.yohoboys.com/contentimg/2016/08/24/13/01ca899c0bcfabdc2128705602aa3f1894.jpg","width":1755,"height":1168,"contentType":0,"title":"Jump Over Jumpman的进击，YEEZY篮球鞋或将推出","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"相信各位对于Kanye West歌曲当中一句Jump Over Jumpman的歌词也是记忆尤深吧，当时歌词一出激起千层浪，引起不少鞋迷的非议，认为Kanye West又在乱说话。然而根据SLAM的消息，Kanye West或将在2017年推出YEEZY篮球鞋。一旦成真，这无疑又是对Air Jord","app":"1","updateMd5":"7f09d4ffcf1870cd17569ad2b89d130e","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20380","cid":"11511","create_time":"1471760341","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11511","image":"http://img01.yohoboys.com/contentimg/2016/08/21/13/01636c9f70235457e5b7e0fe647a3792a7.jpg","width":650,"height":445,"contentType":0,"title":"白金Air Jordan 11 Low，国内再引发售新高","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"Air Jordan 11这个鞋款无论是高帮还是低帮，一直都深受鞋迷的喜爱。乘着里约奥运的东风，Nike亦适时推出多款金牌配色的新作，其中Air Jordan 11 Low白金配色就是其一。目前Nike已经正式公布Air Jordan 11 Low白金配色的发售信息，然而让人吃惊的是。本次发售的Ai","app":"1","updateMd5":"c5669c09cfa0d12f1b6de7bd52559130","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20280","cid":"11427","create_time":"1471236949","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11427","image":"http://img01.yohoboys.com/contentimg/2016/08/15/12/01c47ef7d675dca069473c1a4b17da394a.jpg","width":800,"height":541,"contentType":0,"title":"明年或许你能买到Air Jordan Pure Money系列","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"球鞋的配色一直会直接影响鞋款外观的吸引力，不知道各位是否记得Air Jordan曾经推出Pure Money的纯白系列呢。上一回出现是在2006年，时隔十年，网上盛传Air Jordan Pure Money系列或将在2017年再次复刻。根据DJ Folk的爆料，2017年发售的Air Jordan Pure Money系列包括 Air Jordan4、 Air Jordan 7、 Air Jordan 14。尽管官方还没有确认此消息，但是相信不少鞋迷也会","app":"1","updateMd5":"3e2d5a4ae901e7d2cfd17b9e97555129","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20237","cid":"11389","create_time":"1470893918","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11389","image":"http://img02.yohoboys.com/contentimg/2016/08/11/13/02f8ba166c396c2c742a6c76062ad0131a.jpg","width":1000,"height":600,"contentType":0,"title":"咦？这块Air Jordan奖牌怎么被咬了！","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"里约奥运已经紧张地进行，各大商家当然也会乘着奥运这股风潮推出创意产品。近日美国洛杉矶的艺术家、设计师Matthew Senna就以常见的金银铜奖牌作为灵感，选用Air Jordan常见的吊牌作为蓝本，推出相当别致的Air Jordan奖牌。将以往塑料吊牌摇身一变成为24K金、纯银、纯铜的材质。并以咬一口的设计作为亮点。据悉Air Jordan奖牌已经在其设计师","app":"1","updateMd5":"76adad590b2a3f980aa1055f3dc6bdc4","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20147","cid":"11308","create_time":"1470565063","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11308","image":"http://img02.yohoboys.com/contentimg/2016/08/07/02/0215423c6e68c251c13964c155db107518.jpg","width":650,"height":445,"contentType":0,"title":"YEEZY或将延迟发售，9月迎战Air Jordan \u201cBanned\u201d","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"早前有消息称，8月将会开售Kanye West多次着用的YEEZY BOOST 350 V2。而近日又传来相关发售消息的调整，据悉8月份只会发售婴儿版本，成人尺码的版本或将延期至9月3日发售。如果消息得到官方确认，那么9月3日将会是非常有意思的一天。因为Air Jordan 1与31 \u201cBanned\u201d原本亦会在当天发售，假若YEEZY BOOST 350 V2在当天发售，那么将会是两者的正面交锋","app":"1","updateMd5":"5abc250f9b4076400bd11fbbab370d9e","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]}],"total":99,"title":"AJ Girls","subtitle":"AJ Girls","summary":"球鞋也性感的秘诀就是着上AJ！"}
     * message :
     */

    private String status;
    private int code;
    private DataBean data;
    private String message;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class DataBean {
        /**
         * content : [{"id":"22617","cid":"13355","create_time":"1480923508","publishURL":"http://www.yohoboys.com/channel/detail/index/id/13355","image":"http://img01.yohoboys.com/contentimg/2016/12/05/20/01b3ccbc8992811a8ef58c75e2384c2f49.png","width":738,"height":424,"contentType":0,"title":"SNKR Girl｜这群球鞋妹纸腿长身材好，让我忘记了现在是冬天！11.28-12.4","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"注意！注意！注意！[ 11.21 - 11.27 ]得奖的 SNKR Girls要揭晓了！[ 11.21 - 11.27 ]中获奖的SNKR Girls分别是：第一名：27号🎈 1024票第二名：7号Mumian_ZJ431票第三名：6号Olivia355票本期投稿的SNKR Girls如下：1号오","app":"1","updateMd5":"87210f2940dfdff0d674d43110c9a3ec","imgNum":0,"type":2,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"22517","cid":"13273","create_time":"1480665655","publishURL":"http://www.yohoboys.com/channel/detail/index/id/13273","image":"http://img01.yohoboys.com/contentimg/2016/12/02/15/01243b24c45e8344d1432c5fba626f00b4.png","width":738,"height":424,"contentType":0,"title":"那些年他在奇才穿过的Jordan球鞋","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"2001年9月25日，38岁的Michael Jordan再一次宣布复出，并与华盛顿奇才签订了为期2年的合同，这次复出的目的对于他本人来说是希望通过自己的能力帮助球队打入季后赛，但经过了两个赛季的尝试，最终未果。从Michael Jordan的整个职业生涯来看，在奇才队效力的两年更像是为了证明在这个","app":"1","updateMd5":"5f3e051798d94ad50f92cb6cbe7f557e","imgNum":0,"type":2,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"22231","cid":"13067","create_time":"1480329088","publishURL":"http://www.yohoboys.com/channel/detail/index/id/13067","image":"http://img01.yohoboys.com/contentimg/2016/11/28/18/016906b8d4e7b110ec89e873001f8bf9ce.jpg","width":738,"height":424,"contentType":0,"title":"SNKR Girl｜长腿Supreme、Bape Girl潮到爆，我并不想看鞋！11.21-11.27","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"注意！注意！注意！[ 11.14 - 11.20 ]得奖的 SNKR Girls要揭晓了！[ 11.14 - 11.20 ]中获奖的SNKR Girls分别是\n第一名：\n30号 \n_Kaito\n2756票\n第二、三名分别是：\n6号 \nUKl🌞\n1026票\n13号 \nBlack\n702票","app":"1","updateMd5":"19b0782a744e5b4fdfb34f447039b0ff","imgNum":0,"type":2,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"22075","cid":"12937","create_time":"1479903810","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12937","image":"http://img01.yohoboys.com/contentimg/2016/11/23/19/018908a6973dd654bb9fba74ec471e6838.jpg","width":620,"height":356,"contentType":0,"title":"Jordan Bastille新店开幕，限量Air Jordan黄金纯白套装有点贵","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"发展稳健的Jordan Brand 近日正式在巴黎开设首家零售店Jordan Bastille，为本次开业活动造势，品牌找来退役签约球员雷阿伦，并且一系列的全白白与黄金配色组成的 Air Jordan 套装出现在店铺橱柜之中。\n可以肯定是，本次整套Air Jordan 鞋款的出现旨在纪念本次店铺","app":"1","updateMd5":"bb22922f3342f90b5ccdf9af821ea420","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21999","cid":"12862","create_time":"1479818390","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12862","image":"http://img01.yohoboys.com/contentimg/2016/11/22/20/01a056e355ea5acec5134aac8c37a2031b.png","width":738,"height":424,"contentType":0,"title":"SNKR Girl｜带\u201c球\u201d撞人！犯规！11.14-11.20","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"注意！注意！注意！\n[ 11.7 - 11.13 ]得奖的 SNKR Girls要揭晓了！\n[ 11.7 - 11.13 ]中获奖的SNKR Girls分别是第一名：\n20号 \nAih 菲哥 \n4086票\n第二、三名分别是：\n25号 \n倾🕊 \n2631票\n5号 \nUKl🌞 \n","app":"1","updateMd5":"1c7f234b433131c6fde2cf24c4c7cf1d","imgNum":0,"type":2,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21796","cid":"12675","create_time":"1479204417","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12675","image":"http://img01.yohoboys.com/spidercms/2016/11/14/10/fb05a79f70fa948694c4ffd049e70707147909138084582924b4e3563","width":710,"height":394,"contentType":0,"title":"SNKR Girl｜一众潮爆Girl能否击败拿过第一的翘臀妹纸？！11.7-11.13","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"注意！注意！注意！[ 10.31 - 11.6 ]得奖的 SNKR Girls揭晓了！[ 10.31 - 11.6 ]中获奖的SNKR Girls分别是：\n第一名\n15号：Aih 菲哥我是你淇哥🌡 \n992票\n第二、三名分别是：\n28号：阿哈\n817票\n1号：🤗 Been There Don","app":"1","updateMd5":"8cb5782b29083ea0de84bc27707ad1b9","imgNum":0,"type":2,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21719","cid":"12609","create_time":"1478829956","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12609","image":"http://img02.yohoboys.com/contentimg/2016/11/11/03/027541a8c2592e841e8b1a5a2fbedc751f.jpg","width":650,"height":445,"contentType":4,"title":"Michael Lau巨作《Jordan 本色之墙》即将拍卖，天价在所难免","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"Michael Lau这个名字相信潮流爱好者都不会陌生，这位来自香港的艺术家，在Air Jordan 30周年之时展示出了自己的巨作《Jordan 本色志墙》。整个作品的灵感来自于粉丝对\u201c是什么让你成为 Jordan？\u201d这个问题，将粉丝的回答作为创作的元素。近日Jordan Brand决定对这幅巨作","app":"1","updateMd5":"0a0c096561bfe3b979fd8d0db7d68ea0","imgNum":11,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21554","cid":"12466","create_time":"1478230180","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12466","image":"http://img02.yohoboys.com/contentimg/2016/11/04/13/0264d40718774033c8a4a8d7013d1b430c.jpg","width":746,"height":747,"contentType":0,"title":"网友脑洞大开，仿造天价GUCCI拖鞋","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"日前GUCCI带来了品牌复古感极强的一个系列，双G与红绿的标志性设计再次引起大家的共鸣。但是毕竟是GUCCI，价格也摆在面前成为不少人的门槛。但是如果告诉你有一种低门槛方法让你拥有最近再次大热的红绿GUCCI拖鞋，你又会否感兴趣呢？有网友脑洞大开，亲自将自己的Air Jordan拖鞋进行改造，需要的","app":"1","updateMd5":"4d6c0962d3e609db91b8b9c1e1c366f8","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21333","cid":"12304","create_time":"1477283356","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12304","image":"http://img01.yohoboys.com/contentimg/2016/10/23/23/0114f1e7c7c0db26d11bfa79f878928b54.jpg","width":738,"height":424,"contentType":0,"title":"吸睛利器优选，爆裂纹加持全皮Air Jordan XXXI","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"作为Jordan Brand最新鞋款，Air Jordan XXXI 凝聚了品牌对于当今实战鞋款最强实力，值得注意的是推出之后相对频繁的配色更新也是眼前一亮。近日全新的\u201cBattle Grey\u201d爆裂纹配色正式推出。\n提起爆裂纹配色，更多的则是集中在Air Jordan 3上的火热，本次加持 Air ","app":"1","updateMd5":"8ef826593edae1933973513ded1ad852","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21283","cid":"12267","create_time":"1476845022","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12267","image":"http://img02.yohoboys.com/contentimg/2016/10/19/01/02262f21ece8ea58bc23f8a36f95e641d0.jpg","width":738,"height":424,"contentType":0,"title":"威少不满意新鞋？特别版本Air Jordan XXXI 亮相赛场","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"作为Jordan Brand的招牌代言人，雷霆队当家球星维斯布鲁克上脚球鞋无疑成为众多粉丝及鞋迷关注焦点，但近日一双实战鞋款让人倍感意外。\n提及意外元素，则是其在Air Jordan XXXI 的鞋面加持了Air Jordan XXX 的鞋底，这样的选择也是让人猜测绵绵。首先这双鞋款是否为延伸版的A","app":"1","updateMd5":"fe28e1fb266d8df1a5c6c667e728527f","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21217","cid":"12212","create_time":"1476247617","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12212","image":"http://img02.yohoboys.com/contentimg/2016/10/12/12/024d7ec5721420de516229ecda161b9d68.jpg","width":750,"height":527,"contentType":4,"title":"全新飞人足球靴现身，\u201cFire Red\u201d联名实物曝光","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"此前网络上一张内马尔与乔帮主的照片，引起网友的猜测会否带来合作，果不其然双方采用联名的方式发布了限定商品，其中足球靴与篮球鞋极受关注。近日曝光了第二弹的合作，而本次率先出现的是足球靴，鞋型选用毒蜂二代战靴，以招牌的\u201cFire Red\u201d配色贯彻，白红作为鞋款主要色调，泼墨元素作为设计细节，后跟出现标志","app":"1","updateMd5":"7bbfc223973b7478f6bbbbdc7fca8fec","imgNum":13,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21167","cid":"12174","create_time":"1475985751","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12174","image":"http://img01.yohoboys.com/contentimg/2016/10/09/09/0140540dc30c9544dd43ea0195e1b87d65.png","width":738,"height":424,"contentType":0,"title":"独特的北卡蓝魅力，Air Jordan XXXI新作配色现身","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"Air Jordan绵延至今已经成为众多粉丝必备之物，品牌也在发展中愈发活跃，今年发售的Air Jordan XXXI 在里约奥运会前夕推出后成功抢占多个标志配色，近日经典的\u201c北卡\u201d配色正式曝光。\n首先这款配色的曝光源自北卡大学篮球队官方 Instagram，这样一来可信度的提升对于产品发售将是直接","app":"1","updateMd5":"21c441dda9963e7cb83c30af5934738c","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"21043","cid":"12077","create_time":"1474866214","publishURL":"http://www.yohoboys.com/channel/detail/index/id/12077","image":"http://img01.yohoboys.com/contentimg/2016/09/26/12/01d0823479a5e37b8d791813d889dbf163.jpg","width":650,"height":445,"contentType":0,"title":"3款全新Air Jordan 11 low首次曝光","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"在Air Jordan的系列鞋款当中，Air Jordan 11 low长期保有较高的人气，成为不少鞋迷关注的焦点。近日网络上曝光了三款全新的Air Jordan 11 low全新配色，分别是纯白、黑银、蓝紫。他们的共同点都是以纯白中底结合抗氧化能力较好的淡蓝色水晶外底。据悉这三款全新的Air Jo","app":"1","updateMd5":"97124184fb396e3bad0a69b0215d9231","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20602","cid":"11698","create_time":"1473142906","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11698","image":"http://img02.yohoboys.com/contentimg/2016/09/06/13/02484764f322c1906c883bae8a7daec9c1.jpg","width":650,"height":445,"contentType":4,"title":"大黄靴即视感Air Jordan 4 Premium \u201cGinger\u201d","titleFont":"c","subTitleFont":"c","subtitle":"#球鞋星期二","summary":"此前网络上出现一双姜黄色Air Jordan 4，当时不少人对鞋子的外观褒贬不一。因为这双彻头彻尾都是姜黄色的Air Jordan 4颇有Timberland靴款的风范。目前随着更多的实物图片曝光，相信大家逐渐对这双\u201c踢不烂\u201dAir Jordan 4会有新的感觉。这双Air Jordan 4属于\u201cP","app":"1","updateMd5":"7e43ffb86a15b210898afc6ead299ac5","imgNum":11,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20582","cid":"11683","create_time":"1473048020","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11683","image":"http://img01.yohoboys.com/contentimg/2016/09/05/11/010fb766854fe8de9dd56bd4b49052eaab.jpg","width":650,"height":434,"contentType":0,"title":"Air Jordan 4\u201cPure Money\u201d约你明年6月见！","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"早前已经为各位预告过Pure Money纯白系列将会在明年复刻，根据最新消息复刻的Pure Money系列，除了Air Jordan 4这个经典鞋型，还会有Air Jordan 7和Air Jordan 13亦在复刻名单当中。目前关于实物谍照的图片仍未有曝光，相信会在近期出现相关实物谍照。而发售时间","app":"1","updateMd5":"f5c483b9e30327848236853c556cf839","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20425","cid":"11550","create_time":"1472019858","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11550","image":"http://img01.yohoboys.com/contentimg/2016/08/24/13/01ca899c0bcfabdc2128705602aa3f1894.jpg","width":1755,"height":1168,"contentType":0,"title":"Jump Over Jumpman的进击，YEEZY篮球鞋或将推出","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"相信各位对于Kanye West歌曲当中一句Jump Over Jumpman的歌词也是记忆尤深吧，当时歌词一出激起千层浪，引起不少鞋迷的非议，认为Kanye West又在乱说话。然而根据SLAM的消息，Kanye West或将在2017年推出YEEZY篮球鞋。一旦成真，这无疑又是对Air Jord","app":"1","updateMd5":"7f09d4ffcf1870cd17569ad2b89d130e","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20380","cid":"11511","create_time":"1471760341","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11511","image":"http://img01.yohoboys.com/contentimg/2016/08/21/13/01636c9f70235457e5b7e0fe647a3792a7.jpg","width":650,"height":445,"contentType":0,"title":"白金Air Jordan 11 Low，国内再引发售新高","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"Air Jordan 11这个鞋款无论是高帮还是低帮，一直都深受鞋迷的喜爱。乘着里约奥运的东风，Nike亦适时推出多款金牌配色的新作，其中Air Jordan 11 Low白金配色就是其一。目前Nike已经正式公布Air Jordan 11 Low白金配色的发售信息，然而让人吃惊的是。本次发售的Ai","app":"1","updateMd5":"c5669c09cfa0d12f1b6de7bd52559130","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20280","cid":"11427","create_time":"1471236949","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11427","image":"http://img01.yohoboys.com/contentimg/2016/08/15/12/01c47ef7d675dca069473c1a4b17da394a.jpg","width":800,"height":541,"contentType":0,"title":"明年或许你能买到Air Jordan Pure Money系列","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"球鞋的配色一直会直接影响鞋款外观的吸引力，不知道各位是否记得Air Jordan曾经推出Pure Money的纯白系列呢。上一回出现是在2006年，时隔十年，网上盛传Air Jordan Pure Money系列或将在2017年再次复刻。根据DJ Folk的爆料，2017年发售的Air Jordan Pure Money系列包括 Air Jordan4、 Air Jordan 7、 Air Jordan 14。尽管官方还没有确认此消息，但是相信不少鞋迷也会","app":"1","updateMd5":"3e2d5a4ae901e7d2cfd17b9e97555129","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20237","cid":"11389","create_time":"1470893918","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11389","image":"http://img02.yohoboys.com/contentimg/2016/08/11/13/02f8ba166c396c2c742a6c76062ad0131a.jpg","width":1000,"height":600,"contentType":0,"title":"咦？这块Air Jordan奖牌怎么被咬了！","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"里约奥运已经紧张地进行，各大商家当然也会乘着奥运这股风潮推出创意产品。近日美国洛杉矶的艺术家、设计师Matthew Senna就以常见的金银铜奖牌作为灵感，选用Air Jordan常见的吊牌作为蓝本，推出相当别致的Air Jordan奖牌。将以往塑料吊牌摇身一变成为24K金、纯银、纯铜的材质。并以咬一口的设计作为亮点。据悉Air Jordan奖牌已经在其设计师","app":"1","updateMd5":"76adad590b2a3f980aa1055f3dc6bdc4","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]},{"id":"20147","cid":"11308","create_time":"1470565063","publishURL":"http://www.yohoboys.com/channel/detail/index/id/11308","image":"http://img02.yohoboys.com/contentimg/2016/08/07/02/0215423c6e68c251c13964c155db107518.jpg","width":650,"height":445,"contentType":0,"title":"YEEZY或将延迟发售，9月迎战Air Jordan \u201cBanned\u201d","titleFont":"c","subTitleFont":"c","subtitle":"","summary":"早前有消息称，8月将会开售Kanye West多次着用的YEEZY BOOST 350 V2。而近日又传来相关发售消息的调整，据悉8月份只会发售婴儿版本，成人尺码的版本或将延期至9月3日发售。如果消息得到官方确认，那么9月3日将会是非常有意思的一天。因为Air Jordan 1与31 \u201cBanned\u201d原本亦会在当天发售，假若YEEZY BOOST 350 V2在当天发售，那么将会是两者的正面交锋","app":"1","updateMd5":"5abc250f9b4076400bd11fbbab370d9e","imgNum":0,"type":0,"tag":[{"tag_name":"Air Jordan","tag_id":"40","type":3}]}]
         * total : 99
         * title : AJ Girls
         * subtitle : AJ Girls
         * summary : 球鞋也性感的秘诀就是着上AJ！
         */

        private int total;
        private String title;
        private String subtitle;
        private String summary;
        private List<ContentBean> content;

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getSubtitle() {
            return subtitle;
        }

        public void setSubtitle(String subtitle) {
            this.subtitle = subtitle;
        }

        public String getSummary() {
            return summary;
        }

        public void setSummary(String summary) {
            this.summary = summary;
        }

        public List<ContentBean> getContent() {
            return content;
        }

        public void setContent(List<ContentBean> content) {
            this.content = content;
        }

        public static class ContentBean {
            /**
             * id : 22617
             * cid : 13355
             * create_time : 1480923508
             * publishURL : http://www.yohoboys.com/channel/detail/index/id/13355
             * image : http://img01.yohoboys.com/contentimg/2016/12/05/20/01b3ccbc8992811a8ef58c75e2384c2f49.png
             * width : 738
             * height : 424
             * contentType : 0
             * title : SNKR Girl｜这群球鞋妹纸腿长身材好，让我忘记了现在是冬天！11.28-12.4
             * titleFont : c
             * subTitleFont : c
             * subtitle :
             * summary : 注意！注意！注意！[ 11.21 - 11.27 ]得奖的 SNKR Girls要揭晓了！[ 11.21 - 11.27 ]中获奖的SNKR Girls分别是：第一名：27号🎈 1024票第二名：7号Mumian_ZJ431票第三名：6号Olivia355票本期投稿的SNKR Girls如下：1号오
             * app : 1
             * updateMd5 : 87210f2940dfdff0d674d43110c9a3ec
             * imgNum : 0
             * type : 2
             * tag : [{"tag_name":"Air Jordan","tag_id":"40","type":3}]
             */

            private String id;
            private String cid;
            private String create_time;
            private String publishURL;
            private String image;
            private int width;
            private int height;
            private int contentType;
            private String title;
            private String titleFont;
            private String subTitleFont;
            private String subtitle;
            private String summary;
            private String app;
            private String updateMd5;
            private int imgNum;
            private int type;
            private List<TagBean> tag;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getCid() {
                return cid;
            }

            public void setCid(String cid) {
                this.cid = cid;
            }

            public String getCreate_time() {
                return create_time;
            }

            public void setCreate_time(String create_time) {
                this.create_time = create_time;
            }

            public String getPublishURL() {
                return publishURL;
            }

            public void setPublishURL(String publishURL) {
                this.publishURL = publishURL;
            }

            public String getImage() {
                return image;
            }

            public void setImage(String image) {
                this.image = image;
            }

            public int getWidth() {
                return width;
            }

            public void setWidth(int width) {
                this.width = width;
            }

            public int getHeight() {
                return height;
            }

            public void setHeight(int height) {
                this.height = height;
            }

            public int getContentType() {
                return contentType;
            }

            public void setContentType(int contentType) {
                this.contentType = contentType;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getTitleFont() {
                return titleFont;
            }

            public void setTitleFont(String titleFont) {
                this.titleFont = titleFont;
            }

            public String getSubTitleFont() {
                return subTitleFont;
            }

            public void setSubTitleFont(String subTitleFont) {
                this.subTitleFont = subTitleFont;
            }

            public String getSubtitle() {
                return subtitle;
            }

            public void setSubtitle(String subtitle) {
                this.subtitle = subtitle;
            }

            public String getSummary() {
                return summary;
            }

            public void setSummary(String summary) {
                this.summary = summary;
            }

            public String getApp() {
                return app;
            }

            public void setApp(String app) {
                this.app = app;
            }

            public String getUpdateMd5() {
                return updateMd5;
            }

            public void setUpdateMd5(String updateMd5) {
                this.updateMd5 = updateMd5;
            }

            public int getImgNum() {
                return imgNum;
            }

            public void setImgNum(int imgNum) {
                this.imgNum = imgNum;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public List<TagBean> getTag() {
                return tag;
            }

            public void setTag(List<TagBean> tag) {
                this.tag = tag;
            }

            public static class TagBean {
                /**
                 * tag_name : Air Jordan
                 * tag_id : 40
                 * type : 3
                 */

                private String tag_name;
                private String tag_id;
                private int type;

                public String getTag_name() {
                    return tag_name;
                }

                public void setTag_name(String tag_name) {
                    this.tag_name = tag_name;
                }

                public String getTag_id() {
                    return tag_id;
                }

                public void setTag_id(String tag_id) {
                    this.tag_id = tag_id;
                }

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }
            }
        }
    }
}
